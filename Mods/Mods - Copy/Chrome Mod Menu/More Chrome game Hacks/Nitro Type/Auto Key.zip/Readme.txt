    AUTO KEY CLICKER
=========================

AutoKeyClicker is a small program that I wrote when I was bored, which inputs the specified keystrokes at the specified rate. It should support all the keys on a standard keyboard.



Made by CPScript